package Aula05;

import java.util.Scanner;

public class Ex3 {
	public static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int equals;

		Circle circle[] = new Circle[10];
		for(int i=0; i<circle.length; i++) {
			circle[i] = new Circle( Math.floor(Math.random()) * 5 );
		}
		for (int i = 0; i < circle.length; i++) {
			System.out.println(circle[i]);
		}
		equals = 0;
		for (int i = 0; i < circle.length; i++) {
			for (int j = i; j < circle.length; j++) {
				if(circle[i].equals(circle[j]))
					equals++;
			}
		}
		System.out.println("Existem " + equals + "circulos iguais!");

		Triangulo triangulo[] = new Triangulo[10];
		for(int i=0; i<triangulo.length; i++) {
			triangulo[i] = new Triangulo( Math.floor(Math.random()) * 2, Math.floor(Math.random()) * 2, Math.floor(Math.random()) * 2 );
		}
		for (int i = 0; i < triangulo.length; i++) {
			System.out.println(triangulo[i]);
		}
		equals = 0;
		for (int i = 0; i < triangulo.length; i++) {
			for (int j = i; j < triangulo.length; j++) {
				if(triangulo[i].equals(triangulo[j]))
					equals++;
			}
		}
		System.out.println("Existem " + equals + "triangulos iguais!");

		Retangulo retangulo[] = new Retangulo[10];
		for(int i=0; i<retangulo.length; i++) {
			retangulo[i] = new Retangulo( Math.floor(Math.random()) * 2, Math.floor(Math.random()) * 2 );
		}
		for (int i = 0; i < retangulo.length; i++) {
			System.out.println(retangulo[i]);
		}
		equals = 0;
		for (int i = 0; i < retangulo.length; i++) {
			for (int j = i; j < retangulo.length; j++) {
				if(retangulo[i].equals(retangulo[j]))
					equals++;
			}
		}
		System.out.println("Existem " + equals + "retangulos iguais!");
	}
}
