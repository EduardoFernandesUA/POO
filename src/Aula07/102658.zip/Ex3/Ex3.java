package Aula07.Ex3;

public class Ex3 {
    public static void main(String[] args) {
        // menus e
        // testes que verificam as classes criadas
    }
}
