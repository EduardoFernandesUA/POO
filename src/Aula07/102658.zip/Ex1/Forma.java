package Aula07.Ex1;

public class Forma {
    private String cor;

    public boolean equals(Forma other) {
        return this.cor.equals(other.cor);
    }
}
