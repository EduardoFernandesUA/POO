package Aula07.Ex4;

public class Ex4 {
    public static void main(String[] args) throws InterruptedException {
        Jogo jogo = new Jogo(5);
        Thread.sleep(3500);
        System.out.println(jogo.getCurrentTime());

        /* usar funções e marcar golos */
    }

}
